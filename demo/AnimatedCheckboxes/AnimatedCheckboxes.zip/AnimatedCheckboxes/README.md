
Animated Checkboxes and Radio Buttons with SVG
=========


[Article on Codrops](http://tympanus.net/codrops/?p=16637)

[Demo](http://tympanus.net/Development/AnimatedCheckboxes/)

Integrate or build upon it for free in your personal or commercial projects. Don't republish, redistribute or sell "as-is". 

Read more here: [License](http://tympanus.net/codrops/licensing/)


[© Codrops 2013](http://www.codrops.com)